﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ragister
{
    public partial class home : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Sony\Documents\database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        public home()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Sony\Documents\database1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            SqlCommand cmd = new SqlCommand("sp_insert", con);
          Double price = Convert.ToDouble(textBox3.Text) * Convert.ToDouble(textBox4.Text) * 6.4;
          label3.Text =Convert.ToString( price);
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            add_user unm = new add_user();
            unm.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            string qry = "select name from users where id='"+textBox1.Text+"'";
            SqlDataAdapter da1 = new SqlDataAdapter(qry,con);
            DataTable dt = new DataTable();
            da1.Fill(dt);
            if (dt.Rows.Count >= 1)
            {
                textBox2.Text = (string)dt.Rows[0]["name"];
            }
            else
            {
                MessageBox.Show("Please add user first");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            gridview1 gv = new gridview1();
            gv.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }
    }
}
