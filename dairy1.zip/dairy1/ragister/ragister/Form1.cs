﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ragister
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Sony\Documents\database1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                string name = textBox1.Text;
                string password = textBox2.Text;
                string query = "SELECT unm , pass FROM reg where unm='" + name + "' and pass='" + password + "'";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);


                if (dt.Rows.Count >= 1)
                {
                    MessageBox.Show("done");
                    this.Hide();
                    home hm = new home();
                    hm.Show();
                }
                else
                {
                    MessageBox.Show("Please, Enter valid username or password ");
                }

            }
            //SqlDataReader reader = cmd.ExecuteReader();

            //while (reader.Read())
            //{
            //    if (reader.GetValue(0).ToString() == Convert.ToString(textBox1.Text) && reader.GetValue(1).ToString()==Convert.ToString(textBox2.Text))
            //    { MessageBox.Show("done");
            //    this.Hide();
            //    home hm = new home();
            //    hm.Show();
            //    }
            //    else
            //    {
            //        MessageBox.Show("Please, Enter valid username or password");
            //    }
              
            //}
           
            con.Close();
         
           /* string user, pass;
            user = textBox1.Text;
            pass = textBox2.Text;
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Sony\Documents\login.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            string sql = "insert into login values('"+user+"','"+pass+"')";
            SqlDataAdapter da= sql*/
        
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            register rg = new register();
            rg.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        } 
    }
}
