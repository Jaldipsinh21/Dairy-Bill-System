﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace ragister
{
    public partial class add_user : Form
    {
        public add_user()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Sony\Documents\database1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string qry = "select id from users where id='" + textBox1.Text + "'";
            SqlDataAdapter da1 = new SqlDataAdapter(qry, con);
            DataTable dt = new DataTable();
            da1.Fill(dt);
            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("Id Already Exist");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string qry = "select id from users where id='"+textBox1.Text+"'";
            SqlDataAdapter da1 = new SqlDataAdapter(qry, con);
            DataTable dt = new DataTable();
            da1.Fill(dt);
            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("Id Already Exist");
            }

            else
            {
                try
                {
                    con.Open();
                    if (textBox1.Text != "" && textBox2.Text != "")
                    {

                        string query = "INSERT INTO users  VALUES('" + textBox1.Text + "','" + textBox2.Text + "')";
                        DataSet ds = new DataSet();

                        SqlDataAdapter da = new SqlDataAdapter(query, con);
                        da.Fill(ds);
                        this.Hide();
                        home hm = new home();
                        hm.Show();
                        MessageBox.Show("done");
                        con.Close();
                    }
                    else
                    {
                        MessageBox.Show("Please enter some value");
                    }
                }
                catch { }
            }
         
         
         
         
        }

        private void add_user_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
