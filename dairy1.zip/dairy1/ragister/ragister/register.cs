﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ragister
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Sony\Documents\database1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == textBox3.Text)
            {
                string query = "INSERT INTO  reg VALUES('" + textBox1.Text + "','" + textBox2.Text + "') ";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                MessageBox.Show("done");

                this.Hide();
                Form1 lg = new Form1();
                lg.Show();
            }
            else
            {
                MessageBox.Show("Password Doesn't Match");
            }
        }

        private void register_Load(object sender, EventArgs e)
        {

        }
    }
}
